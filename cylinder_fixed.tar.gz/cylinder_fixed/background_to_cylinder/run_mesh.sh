#!/bin/bash


foamCleanTutorials

cd background
blockMesh


cd ..
cd cylinder
blockMesh

mergeMeshes . ../background -overwrite

changeDictionary

checkMesh |  tee log.checkMesh

rm -r 0

cp -r 0_org 0

#checkMesh |  tee log.checkMesh

setFields | tee log.setFields


