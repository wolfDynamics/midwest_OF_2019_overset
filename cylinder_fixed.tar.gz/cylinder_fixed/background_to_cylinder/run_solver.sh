 #!/bin/bash

cd cylinder

setFields -dict system/setFieldsDict_init 

decomposePar

mpirun -np 4 renumberMesh -overwrite -parallel | tee log.renumberMesh

mpirun -np 4 overPimpleDyMFoam -parallel | tee log.solver

