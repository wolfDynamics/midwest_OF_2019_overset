#!/bin/bash


foamCleanTutorials

cd cylinder
blockMesh | tee log.blockMesh

cd ..

cd all
blockMesh | tee log.blockMesh

mergeMeshes . ../cylinder -overwrite | tee log.mergeMeshes

#createPatch -overwrite | tee log.createPatch
#changeDictionary | tee log.changeDictionary
#topoSet | tee log.topoSet

checkMesh |  tee log.checkMesh

rm -r 0
cp -r 0_org 0

setFields | tee log.setFields


