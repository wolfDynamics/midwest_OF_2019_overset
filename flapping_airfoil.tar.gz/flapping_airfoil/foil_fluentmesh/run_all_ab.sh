#!/bin/bash

foamCleanTutorials
sh run_mesh_ab.sh
sh run_solver_ab.sh
