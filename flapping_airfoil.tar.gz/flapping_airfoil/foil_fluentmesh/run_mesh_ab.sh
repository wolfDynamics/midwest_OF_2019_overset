#!/bin/bash


foamCleanTutorials


cd airfoil
fluentMeshToFoam -2D 1 ../mesh/airfoil.cas
transformPoints -translate '(0 -0.5 0)'
cd ..

cd backGround
fluentMeshToFoam -2D 1 ../mesh/background.cas
mergeMeshes . ../airfoil -overwrite

topoSet
topoSet -dict system/topoSetDict_movingZone


rm -r 0
cp -r 0_org 0


checkMesh |  tee log.checkMesh
setFields | tee log.setFields

changeDictionary | tee log.changeDictionary

cd ..
