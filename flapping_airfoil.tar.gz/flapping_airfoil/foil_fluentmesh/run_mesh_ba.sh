#!/bin/bash


foamCleanTutorials


cd backGround
fluentMeshToFoam -2D 1 ../mesh/background.cas
cd ..

cd airfoil
#fluentMeshToFoam -2D 1 ../mesh/airfoil.cas
fluentMeshToFoam -2D 1 ../mesh/airfoilv2.cas
transformPoints -translate '(0 -0.5 0)'
mergeMeshes . ../backGround -overwrite

#createPatch -overwrite | tee log.createPatch
changeDictionary | tee log.changeDictionary
sed -i 's/overset_patch/wall-airfoil/g' constant/polyMesh/boundary

topoSet
topoSet -dict system/topoSetDict_movingZone


rm -r 0
cp -r 0_org 0


checkMesh |  tee log.checkMesh
setFields | tee log.setFields



cd ..
