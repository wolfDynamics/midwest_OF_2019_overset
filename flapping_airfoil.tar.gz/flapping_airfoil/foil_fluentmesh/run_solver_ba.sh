 #!/bin/bash

#rm -rf all
#cp -r backGround all
#cd all

#setFields -dict system/setFieldsDict_init 


cd airfoil
decomposePar
mpirun -np 4 renumberMesh -overwrite -parallel | tee log.renumberMesh
mpirun -np 4 overPimpleDyMFoam -parallel | tee log.solver


#cd backGround
#renumberMesh -overwrite | tee log.renumberMesh
#overPimpleDyMFoam | tee log.solver
